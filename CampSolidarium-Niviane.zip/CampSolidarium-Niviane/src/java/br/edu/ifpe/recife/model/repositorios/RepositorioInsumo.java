package br.edu.ifpe.recife.model.repositorios;

import br.edu.ifpe.recife.model.negocio.Insumo;
import java.util.ArrayList;
import java.util.List;

public class RepositorioInsumo {
    
    public static List<Insumo> insumos = null;
    
    static {
        insumos = new ArrayList<>();
        
        Insumo insumo = new Insumo();
        insumo.setCodigo(112);
        insumo.setDescricao("Insumo 1");
        insumo.setQuantidade(50);
        insumo.setCategoria("Categoria 1");
        
        insumos.add(insumo);
        
        insumo = new Insumo();
        insumo.setCodigo(331);
        insumo.setDescricao("Insumo 2");
        insumo.setQuantidade(30);
        insumo.setCategoria("Categoria 2");
        
        insumos.add(insumo);
    }
    
    public static void create(Insumo insumo){
        insumos.add(insumo);
    }
    
    public static void update(Insumo insumo){
        
        for(Insumo insumoAux: insumos){
            if(insumoAux.getCodigo() == insumo.getCodigo()){
                insumoAux.setDescricao(insumo.getDescricao());
                insumoAux.setQuantidade(insumo.getQuantidade());
                insumoAux.setCategoria(insumo.getCategoria());
                return;
            }
        }
    }
    
    public static Insumo read(int codigo){
        
        for(Insumo insumoAux: insumos){
            if(insumoAux.getCodigo() == codigo){
                return insumoAux;
            }
        }
        return null;
    }
    
    public static void delete(Insumo insumo){
        insumos.remove(insumo);
    }
    
    public static List<Insumo> readAll(){
        return insumos;
    }
}
