/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpe.recife.model.repositorios;

import br.edu.ifpe.recife.model.negocio.Emergencia;

import java.util.ArrayList;
import java.util.List;

public class RepositorioEmergencia {
    
    private static List<Emergencia> emergencias = null;
    private static int nextCodigo = 1;
    
    static {
        emergencias = new ArrayList<>();
        
        Emergencia emergencia = new Emergencia();
        emergencia.setCodigo(nextCodigo++);
        emergencia.setLocal("Local 1");
        emergencia.setTipo("Tipo 1");
        emergencia.setDescricao("Descrição 1");
        emergencias.add(emergencia);
        
        emergencia = new Emergencia();
        emergencia.setCodigo(nextCodigo++);
        emergencia.setLocal("Local 2");
        emergencia.setTipo("Tipo 2");
        emergencia.setDescricao("Descrição 2");
        emergencias.add(emergencia);
    }

    public static Emergencia create(Emergencia emergencia) {
        emergencia.setCodigo(nextCodigo++);
        emergencias.add(emergencia);
        return emergencia;
    }

    public static void update(Emergencia updatedEmergencia) {
        for (Emergencia emergencia : emergencias) {
            if (emergencia.getCodigo() == updatedEmergencia.getCodigo()) {
                emergencia.setLocal(updatedEmergencia.getLocal());
                emergencia.setTipo(updatedEmergencia.getTipo());
                emergencia.setDescricao(updatedEmergencia.getDescricao());
                return;
            }
        }
    }

    public static Emergencia read(int codigo) {
        for (Emergencia emergencia : emergencias) {
            if (emergencia.getCodigo() == codigo) {
                return emergencia;
            }
        }
        return null;
    }

    public static void delete(Emergencia emergencia) {
        emergencias.remove(emergencia);
    }

    public static List<Emergencia> readAll() {
        return emergencias;
    }
}
