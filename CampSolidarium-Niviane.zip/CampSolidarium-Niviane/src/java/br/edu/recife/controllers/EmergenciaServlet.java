package br.edu.recife.controllers;

import br.edu.ifpe.recife.model.negocio.Emergencia;
import br.edu.ifpe.recife.model.repositorios.RepositorioEmergencia;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class EmergenciaServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            // Página principal de Emergências
            List<Emergencia> emergencias = RepositorioEmergencia.readAll();
            request.setAttribute("emergencias", emergencias);
            request.getRequestDispatcher("emergencias.jsp").forward(request, response);
        } else if (action.equals("create")) {
            // Página de criação de Emergencia
            request.getRequestDispatcher("createEmergencia.jsp").forward(request, response);
        } else if (action.equals("view")) {
            // Visualizar detalhes de uma Emergencia
            int codigo = Integer.parseInt(request.getParameter("codigo"));
            Emergencia emergencia = RepositorioEmergencia.read(codigo);
            request.setAttribute("emergencia", emergencia);
            request.getRequestDispatcher("viewEmergencia.jsp").forward(request, response);
        } else if (action.equals("update")) {
            // Página de atualização de Emergencia
            int codigo = Integer.parseInt(request.getParameter("codigo"));
            Emergencia emergencia = RepositorioEmergencia.read(codigo);
            request.setAttribute("emergencia", emergencia);
            request.getRequestDispatcher("updateEmergencia.jsp").forward(request, response);
        } else if (action.equals("delete")) {
            // Excluir uma Emergencia
            int codigo = Integer.parseInt(request.getParameter("codigo"));
            Emergencia emergencia = RepositorioEmergencia.read(codigo);
            RepositorioEmergencia.delete(emergencia);
            response.sendRedirect("emergencias?action=viewAll");
        }
    }
}
