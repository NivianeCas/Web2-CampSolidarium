/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.recife.controllers;

import br.edu.ifpe.recife.model.negocio.Ong;
import br.edu.ifpe.recife.model.repositorios.RepositorioOng;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author nivia
 */
@WebServlet(name = "CadastroOngServlet", urlPatterns = {"/CadastroOngServlet"})
public class CadastroOngServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recupera os dados do formulário HTML
        int codigo = Integer.parseInt(request.getParameter("codigo"));
        String login = request.getParameter("login");
        String senha = request.getParameter("senha");
        String nome = request.getParameter("nome");
        String endereco = request.getParameter("endereco");
        String email = request.getParameter("email");
        String telefone = request.getParameter("telefone");
        String cnpj = request.getParameter("cnpj");

        // Cria uma instância de Ong com os dados
        Ong ong = new Ong();
        ong.setCodigo(codigo);
        ong.setLogin(login);
        ong.setSenha(senha);
        ong.setNome(nome);
        ong.setEndereco(endereco);
        ong.setEmail(email);
        ong.setTelefone(telefone);
        ong.setCnpj(cnpj);

        // Salva a Ong no sistema
        RepositorioOng.create(ong);

        // Redirecione para uma página de sucesso
        response.sendRedirect("CadastroOngSucesso.html");
    }
}

