package br.edu.recife.controllers;

import br.edu.ifpe.recife.model.negocio.Insumo;
import br.edu.ifpe.recife.model.repositorios.RepositorioInsumo;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class InsumoServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            // Página principal de Insumos
            List<Insumo> insumos = RepositorioInsumo.readAll();
            request.setAttribute("insumos", insumos);
            request.getRequestDispatcher("insumos.jsp").forward(request, response);
        } else if (action.equals("create")) {
            // Página de criação de Insumo
            request.getRequestDispatcher("createInsumo.jsp").forward(request, response);
        } else if (action.equals("view")) {
            // Visualizar detalhes de um Insumo
            int codigo = Integer.parseInt(request.getParameter("codigo"));
            Insumo insumo = RepositorioInsumo.read(codigo);
            request.setAttribute("insumo", insumo);
            request.getRequestDispatcher("viewInsumo.jsp").forward(request, response);
        } else if (action.equals("update")) {
            // Página de atualização de Insumo
            int codigo = Integer.parseInt(request.getParameter("codigo"));
            Insumo insumo = RepositorioInsumo.read(codigo);
            request.setAttribute("insumo", insumo);
            request.getRequestDispatcher("updateInsumo.jsp").forward(request, response);
        } else if (action.equals("delete")) {
            // Excluir um Insumo
            int codigo = Integer.parseInt(request.getParameter("codigo"));
            Insumo insumo = RepositorioInsumo.read(codigo);
            RepositorioInsumo.delete(insumo);
            response.sendRedirect("insumos?action=viewAll");
        }
    }
}
