package br.edu.recife.controllers;

import br.edu.ifpe.recife.model.negocio.Ong;
import br.edu.ifpe.recife.model.repositorios.RepositorioOng;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class OngServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            // Página principal das Ongs
            List<Ong> ongs = RepositorioOng.readAll();
            request.setAttribute("ongs", ongs);
            request.getRequestDispatcher("ongs.jsp").forward(request, response);
        } else if (action.equals("create")) {
            // Página de criação de Ong
            request.getRequestDispatcher("createOng.jsp").forward(request, response);
        } else if (action.equals("view")) {
            // Visualizar detalhes de uma Ong
            int codigo = Integer.parseInt(request.getParameter("codigo"));
            Ong ong = RepositorioOng.read(codigo);
            request.setAttribute("ong", ong);
            request.getRequestDispatcher("viewOng.jsp").forward(request, response);
        } else if (action.equals("update")) {
            // Página de atualização de Ong
            int codigo = Integer.parseInt(request.getParameter("codigo"));
            Ong ong = RepositorioOng.read(codigo);
            request.setAttribute("ong", ong);
            request.getRequestDispatcher("updateOng.jsp").forward(request, response);
        } else if (action.equals("delete")) {
            // Excluir uma Ong
            int codigo = Integer.parseInt(request.getParameter("codigo"));
            Ong ong = RepositorioOng.read(codigo);
            RepositorioOng.delete(ong);
            response.sendRedirect("ongs?action=viewAll");
        }
    }
}
